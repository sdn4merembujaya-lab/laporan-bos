import { db } from '../utils/db.js';
import { rupiah, bulanTahun, tanggalIndo, todayISO } from '../utils/format.js';

export async function renderLaporan(container) {
  const bku = (await db.get('bku', [])) || [];
  const profil = (await db.get('profilSekolah', {})) || {};
  const bulanIni = todayISO().slice(0, 7);

  container.innerHTML = `
    <div class="p-6 space-y-6">
      <div class="flex justify-between items-center no-print">
        <div>
          <h1 class="text-2xl font-bold">Laporan Bulanan BOS</h1>
          <p class="text-slate-400 text-sm mt-1">Siap cetak — Buku Kas Umum bulanan dengan kop resmi</p>
        </div>
        <div class="flex gap-2 items-center">
          <input type="month" id="filterBulan" value="${bulanIni}"
            class="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm" />
          <button id="btnPrint" class="px-4 py-2 bg-brand-600 hover:bg-brand-700 rounded-lg text-sm font-medium">🖨️ Cetak</button>
        </div>
      </div>

      <div id="areaLaporan" class="bg-white text-black rounded-xl p-8 print-area"></div>
    </div>
  `;

  const gambarLaporan = (bulan) => {
    const filtered = bku.filter((t) => t.tanggal.startsWith(bulan)).sort((a, b) => new Date(a.tanggal) - new Date(b.tanggal));
    let saldo = 0;
    const totalMasuk = filtered.filter((t) => t.jenis === 'masuk').reduce((a, b) => a + Number(b.jumlah), 0);
    const totalKeluar = filtered.filter((t) => t.jenis === 'keluar').reduce((a, b) => a + Number(b.jumlah), 0);

    document.getElementById('areaLaporan').innerHTML = `
      <div class="text-center border-b-2 border-black pb-4 mb-6">
        <h2 class="font-bold text-lg uppercase">${profil.namaSekolah || '(Nama Sekolah Belum Diatur)'}</h2>
        <p class="text-sm">${profil.alamat || '(Alamat belum diatur)'}</p>
        <p class="text-sm">NPSN: ${profil.npsn || '-'}</p>
      </div>
      <h3 class="text-center font-bold uppercase mb-1">Buku Kas Umum Dana BOS</h3>
      <p class="text-center text-sm mb-6">Bulan: ${bulanTahun(bulan + '-01')}</p>

      <table class="w-full text-sm border-collapse mb-6">
        <thead>
          <tr class="border border-black">
            <th class="border border-black p-2">Tanggal</th>
            <th class="border border-black p-2">Uraian</th>
            <th class="border border-black p-2">Kode Rek.</th>
            <th class="border border-black p-2">Penerimaan</th>
            <th class="border border-black p-2">Pengeluaran</th>
            <th class="border border-black p-2">Saldo</th>
          </tr>
        </thead>
        <tbody>
          ${
            filtered.length === 0
              ? `<tr><td colspan="6" class="border border-black p-4 text-center">Tidak ada transaksi pada bulan ini</td></tr>`
              : filtered
                  .map((t) => {
                    saldo += t.jenis === 'masuk' ? Number(t.jumlah) : -Number(t.jumlah);
                    return `
              <tr>
                <td class="border border-black p-2">${new Date(t.tanggal).toLocaleDateString('id-ID')}</td>
                <td class="border border-black p-2">${t.uraian}</td>
                <td class="border border-black p-2">${t.kodeRekening || '-'}</td>
                <td class="border border-black p-2 text-right">${t.jenis === 'masuk' ? rupiah(t.jumlah) : ''}</td>
                <td class="border border-black p-2 text-right">${t.jenis === 'keluar' ? rupiah(t.jumlah) : ''}</td>
                <td class="border border-black p-2 text-right">${rupiah(saldo)}</td>
              </tr>`;
                  })
                  .join('')
          }
          <tr class="font-bold">
            <td colspan="3" class="border border-black p-2 text-right">Jumlah</td>
            <td class="border border-black p-2 text-right">${rupiah(totalMasuk)}</td>
            <td class="border border-black p-2 text-right">${rupiah(totalKeluar)}</td>
            <td class="border border-black p-2 text-right">${rupiah(totalMasuk - totalKeluar)}</td>
          </tr>
        </tbody>
      </table>

      <div class="flex justify-between mt-12 text-sm">
        <div class="text-center">
          <p>Bendahara BOS</p>
          <div class="h-20"></div>
          <p class="font-bold underline">${profil.namaBendahara || '(.........................)'}</p>
        </div>
        <div class="text-center">
          <p>${profil.kota || '..........'}, ${tanggalIndo(todayISO())}</p>
          <p>Kepala Sekolah</p>
          <div class="h-20"></div>
          <p class="font-bold underline">${profil.namaKepsek || '(.........................)'}</p>
          <p>NIP. ${profil.nipKepsek || '-'}</p>
        </div>
      </div>
    `;
  };

  gambarLaporan(bulanIni);
  document.getElementById('filterBulan').addEventListener('change', (e) => gambarLaporan(e.target.value));
  document.getElementById('btnPrint').addEventListener('click', () => window.print());
}
