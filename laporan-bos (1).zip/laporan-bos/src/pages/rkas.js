import { db } from '../utils/db.js';
import { rupiah } from '../utils/format.js';

let editId = null;

export async function renderRKAS(container) {
  const data = (await db.get('rkas', [])) || [];

  container.innerHTML = `
    <div class="p-6 space-y-6">
      <div class="flex justify-between items-center no-print">
        <div>
          <h1 class="text-2xl font-bold">RKAS</h1>
          <p class="text-slate-400 text-sm mt-1">Rencana Kegiatan dan Anggaran Sekolah</p>
        </div>
        <button id="btnTambah" class="px-4 py-2 bg-brand-600 hover:bg-brand-700 rounded-lg text-sm font-medium">+ Tambah Kegiatan</button>
      </div>

      <div id="formArea" class="hidden bg-slate-900 border border-slate-800 rounded-xl p-5 no-print"></div>

      <div class="bg-slate-900 rounded-xl border border-slate-800 overflow-hidden">
        <table class="w-full text-sm">
          <thead class="bg-slate-800/50 text-slate-400 text-xs uppercase">
            <tr>
              <th class="text-left px-4 py-3">Kegiatan</th>
              <th class="text-left px-4 py-3">Sumber Dana</th>
              <th class="text-right px-4 py-3">Anggaran</th>
              <th class="text-right px-4 py-3">Realisasi</th>
              <th class="text-right px-4 py-3">Sisa</th>
              <th class="text-center px-4 py-3">Progres</th>
              <th class="text-center px-4 py-3 no-print">Aksi</th>
            </tr>
          </thead>
          <tbody>
            ${
              data.length === 0
                ? `<tr><td colspan="7" class="text-center text-slate-500 py-8">Belum ada kegiatan RKAS</td></tr>`
                : data
                    .map((r) => {
                      const persen = r.anggaran ? Math.min(Math.round((Number(r.realisasi) / Number(r.anggaran)) * 100), 100) : 0;
                      return `
                <tr class="border-t border-slate-800 hover:bg-slate-800/30">
                  <td class="px-4 py-3">${r.kegiatan}</td>
                  <td class="px-4 py-3 text-slate-400">${r.sumberDana || 'BOS'}</td>
                  <td class="px-4 py-3 text-right">${rupiah(r.anggaran)}</td>
                  <td class="px-4 py-3 text-right text-emerald-400">${rupiah(r.realisasi)}</td>
                  <td class="px-4 py-3 text-right">${rupiah(r.anggaran - r.realisasi)}</td>
                  <td class="px-4 py-3">
                    <div class="w-full bg-slate-800 rounded-full h-2">
                      <div class="bg-brand-500 h-2 rounded-full" style="width:${persen}%"></div>
                    </div>
                    <p class="text-xs text-center text-slate-500 mt-1">${persen}%</p>
                  </td>
                  <td class="px-4 py-3 text-center no-print">
                    <button data-edit="${r.id}" class="text-brand-400 hover:underline text-xs mr-2">Edit</button>
                    <button data-hapus="${r.id}" class="text-rose-400 hover:underline text-xs">Hapus</button>
                  </td>
                </tr>`;
                    })
                    .join('')
            }
          </tbody>
        </table>
      </div>
    </div>
  `;

  document.getElementById('btnTambah').addEventListener('click', () => openForm(container));
  container.querySelectorAll('[data-edit]').forEach((btn) =>
    btn.addEventListener('click', () => openForm(container, btn.dataset.edit, data))
  );
  container.querySelectorAll('[data-hapus]').forEach((btn) =>
    btn.addEventListener('click', async () => {
      if (!confirm('Hapus kegiatan ini?')) return;
      const updated = data.filter((r) => r.id !== btn.dataset.hapus);
      await db.set('rkas', updated);
      renderRKAS(container);
    })
  );
}

function openForm(container, id = null, data = []) {
  editId = id;
  const existing = id ? data.find((r) => r.id === id) : null;
  const area = document.getElementById('formArea');
  area.classList.remove('hidden');
  area.innerHTML = `
    <h3 class="font-semibold mb-4">${existing ? 'Edit' : 'Tambah'} Kegiatan RKAS</h3>
    <form id="formRKAS" class="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div class="md:col-span-2">
        <label class="text-xs text-slate-400 block mb-1">Nama Kegiatan</label>
        <input type="text" name="kegiatan" value="${existing?.kegiatan || ''}" required placeholder="Misal: Pengadaan Buku Perpustakaan"
          class="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm" />
      </div>
      <div>
        <label class="text-xs text-slate-400 block mb-1">Sumber Dana</label>
        <input type="text" name="sumberDana" value="${existing?.sumberDana || 'BOS'}"
          class="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm" />
      </div>
      <div>
        <label class="text-xs text-slate-400 block mb-1">Anggaran (Rp)</label>
        <input type="number" name="anggaran" value="${existing?.anggaran || ''}" required min="0"
          class="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm" />
      </div>
      <div>
        <label class="text-xs text-slate-400 block mb-1">Realisasi (Rp)</label>
        <input type="number" name="realisasi" value="${existing?.realisasi || 0}" min="0"
          class="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm" />
      </div>
      <div class="md:col-span-2 flex gap-2 justify-end pt-2">
        <button type="button" id="btnBatal" class="px-4 py-2 bg-slate-800 rounded-lg text-sm">Batal</button>
        <button type="submit" class="px-4 py-2 bg-brand-600 hover:bg-brand-700 rounded-lg text-sm font-medium">Simpan</button>
      </div>
    </form>
  `;

  document.getElementById('btnBatal').addEventListener('click', () => area.classList.add('hidden'));
  document.getElementById('formRKAS').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const payload = Object.fromEntries(fd.entries());
    let list = (await db.get('rkas', [])) || [];

    if (editId) {
      list = list.map((r) => (r.id === editId ? { ...r, ...payload } : r));
    } else {
      list.push({ id: db.uid(), ...payload });
    }
    await db.set('rkas', list);
    editId = null;
    renderRKAS(container);
  });
}
