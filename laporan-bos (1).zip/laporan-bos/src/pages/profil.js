import { db } from '../utils/db.js';

export async function renderProfil(container) {
  const profil = (await db.get('profilSekolah', {})) || {};

  container.innerHTML = `
    <div class="p-6 max-w-2xl">
      <h1 class="text-2xl font-bold mb-1">Profil Sekolah</h1>
      <p class="text-slate-400 text-sm mb-6">Data ini dipakai untuk kop surat pada Laporan cetak</p>

      <form id="formProfil" class="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-4">
        ${field('namaSekolah', 'Nama Sekolah', profil.namaSekolah)}
        ${field('npsn', 'NPSN', profil.npsn)}
        ${field('alamat', 'Alamat', profil.alamat)}
        ${field('kota', 'Kota/Kabupaten', profil.kota)}
        <div class="grid grid-cols-2 gap-4">
          ${field('namaKepsek', 'Nama Kepala Sekolah', profil.namaKepsek)}
          ${field('nipKepsek', 'NIP Kepala Sekolah', profil.nipKepsek)}
        </div>
        ${field('namaBendahara', 'Nama Bendahara BOS', profil.namaBendahara)}

        <div class="flex justify-end pt-2">
          <button type="submit" class="px-4 py-2 bg-brand-600 hover:bg-brand-700 rounded-lg text-sm font-medium">Simpan Profil</button>
        </div>
        <p id="savedMsg" class="text-emerald-400 text-sm hidden">Profil tersimpan ✓</p>
      </form>

      <div class="bg-slate-900 border border-slate-800 rounded-xl p-6 mt-6">
        <h3 class="font-semibold mb-3">Lisensi Aplikasi</h3>
        <div id="licenseInfo" class="text-sm text-slate-400">Memuat...</div>
        <button id="btnNonaktifkan" class="mt-4 px-4 py-2 bg-rose-900/50 hover:bg-rose-900 text-rose-300 rounded-lg text-sm hidden">
          Nonaktifkan Lisensi di Perangkat Ini
        </button>
      </div>
    </div>
  `;

  if (window.api?.checkLicenseStatus) {
    window.api.checkLicenseStatus().then((status) => {
      const info = document.getElementById('licenseInfo');
      const btn = document.getElementById('btnNonaktifkan');
      if (status.activated) {
        info.innerHTML = `<span class="text-emerald-400">✓ Aktif</span>${status.offline ? ' (mode offline)' : ''}`;
        btn.classList.remove('hidden');
        btn.addEventListener('click', async () => {
          if (!confirm('Nonaktifkan lisensi di perangkat ini? Kamu perlu memasukkan key lagi untuk memakai aplikasi.')) return;
          await window.api.deactivateLicense();
          window.location.reload();
        });
      } else {
        info.innerHTML = `<span class="text-rose-400">Tidak aktif</span>`;
      }
    });
  } else {
    document.getElementById('licenseInfo').textContent = 'Tidak tersedia di mode browser/dev.';
  }

  document.getElementById('formProfil').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const payload = Object.fromEntries(fd.entries());
    await db.set('profilSekolah', payload);
    const msg = document.getElementById('savedMsg');
    msg.classList.remove('hidden');
    setTimeout(() => msg.classList.add('hidden'), 2000);
  });
}

function field(name, label, value = '') {
  return `
    <div>
      <label class="text-xs text-slate-400 block mb-1">${label}</label>
      <input type="text" name="${name}" value="${value || ''}"
        class="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm" />
    </div>
  `;
}
