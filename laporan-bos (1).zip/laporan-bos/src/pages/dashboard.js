import { db } from '../utils/db.js';
import { rupiah, bulanTahun } from '../utils/format.js';

export async function renderDashboard(container) {
  const bku = (await db.get('bku', [])) || [];
  const rkas = (await db.get('rkas', [])) || [];
  const profil = (await db.get('profilSekolah', {})) || {};

  const totalMasuk = bku.filter((t) => t.jenis === 'masuk').reduce((a, b) => a + Number(b.jumlah), 0);
  const totalKeluar = bku.filter((t) => t.jenis === 'keluar').reduce((a, b) => a + Number(b.jumlah), 0);
  const saldo = totalMasuk - totalKeluar;
  const totalAnggaranRKAS = rkas.reduce((a, b) => a + Number(b.anggaran || 0), 0);
  const totalRealisasiRKAS = rkas.reduce((a, b) => a + Number(b.realisasi || 0), 0);
  const persenRealisasi = totalAnggaranRKAS ? Math.round((totalRealisasiRKAS / totalAnggaranRKAS) * 100) : 0;

  const transaksiTerbaru = [...bku].sort((a, b) => new Date(b.tanggal) - new Date(a.tanggal)).slice(0, 5);

  container.innerHTML = `
    <div class="p-6 space-y-6">
      <div>
        <h1 class="text-2xl font-bold">Dashboard</h1>
        <p class="text-slate-400 text-sm mt-1">${profil.namaSekolah || 'Nama Sekolah belum diatur'} — ${bulanTahun(new Date().toISOString())}</p>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
        ${statCard('Saldo Kas', rupiah(saldo), 'bg-brand-600')}
        ${statCard('Total Pemasukan', rupiah(totalMasuk), 'bg-emerald-600')}
        ${statCard('Total Pengeluaran', rupiah(totalKeluar), 'bg-rose-600')}
        ${statCard('Realisasi RKAS', persenRealisasi + '%', 'bg-amber-600')}
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div class="lg:col-span-2 bg-slate-900 rounded-xl border border-slate-800 p-5">
          <h2 class="font-semibold mb-4">Transaksi Terbaru (BKU)</h2>
          ${
            transaksiTerbaru.length === 0
              ? '<p class="text-slate-500 text-sm">Belum ada transaksi. Tambahkan lewat menu BKU.</p>'
              : `<div class="space-y-2">${transaksiTerbaru
                  .map(
                    (t) => `
                <div class="flex justify-between items-center py-2 border-b border-slate-800 last:border-0">
                  <div>
                    <p class="text-sm font-medium">${t.uraian}</p>
                    <p class="text-xs text-slate-500">${new Date(t.tanggal).toLocaleDateString('id-ID')}</p>
                  </div>
                  <span class="text-sm font-semibold ${t.jenis === 'masuk' ? 'text-emerald-400' : 'text-rose-400'}">
                    ${t.jenis === 'masuk' ? '+' : '-'} ${rupiah(t.jumlah)}
                  </span>
                </div>`
                  )
                  .join('')}</div>`
          }
        </div>

        <div class="bg-slate-900 rounded-xl border border-slate-800 p-5">
          <h2 class="font-semibold mb-4">Progres Anggaran RKAS</h2>
          <div class="w-full bg-slate-800 rounded-full h-3 mb-2">
            <div class="bg-brand-500 h-3 rounded-full transition-all" style="width:${Math.min(persenRealisasi, 100)}%"></div>
          </div>
          <p class="text-xs text-slate-400">${rupiah(totalRealisasiRKAS)} dari ${rupiah(totalAnggaranRKAS)}</p>
          <p class="text-xs text-slate-500 mt-4">Jumlah item RKAS: ${rkas.length}</p>
        </div>
      </div>
    </div>
  `;
}

function statCard(label, value, color) {
  return `
    <div class="bg-slate-900 rounded-xl border border-slate-800 p-5">
      <div class="w-2 h-2 rounded-full ${color} mb-3"></div>
      <p class="text-slate-400 text-xs mb-1">${label}</p>
      <p class="text-xl font-bold">${value}</p>
    </div>
  `;
}
