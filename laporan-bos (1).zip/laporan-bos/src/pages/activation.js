// Layar ini hanya berfungsi penuh di dalam Electron (butuh window.api).
// Saat dibuka di browser biasa (mode dev web), aktivasi otomatis dilewati.

export async function checkAndRenderActivation(onActivated) {
  const app = document.getElementById('app');

  if (!window.api || !window.api.checkLicenseStatus) {
    // Bukan berjalan di Electron (mis. dev web biasa) — lewati saja
    onActivated();
    return;
  }

  const status = await window.api.checkLicenseStatus();
  if (status.activated) {
    onActivated();
    return;
  }

  renderActivationScreen(app, status.error, onActivated);
}

function renderActivationScreen(app, errorMsg, onActivated) {
  app.innerHTML = `
    <div class="h-screen flex items-center justify-center bg-slate-950">
      <div class="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl p-8">
        <div class="text-center mb-6">
          <div class="text-3xl mb-2">💰</div>
          <h1 class="text-xl font-bold">Aktivasi Laporan BOS</h1>
          <p class="text-slate-400 text-sm mt-1">Masukkan license key untuk mengaktifkan aplikasi di perangkat ini</p>
        </div>

        ${errorMsg ? `<div class="bg-rose-950 border border-rose-800 text-rose-300 text-sm rounded-lg p-3 mb-4">${errorMsg}</div>` : ''}

        <form id="formAktivasi" class="space-y-4">
          <div>
            <label class="text-xs text-slate-400 block mb-1">License Key</label>
            <input type="text" id="licenseKeyInput" placeholder="LBOS-XXXX-XXXX-XXXX-XXXX" required
              class="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2.5 text-sm tracking-wider uppercase font-mono" />
          </div>
          <button type="submit" id="btnAktivasi"
            class="w-full bg-brand-600 hover:bg-brand-700 rounded-lg py-2.5 text-sm font-medium transition">
            Aktifkan
          </button>
          <p id="statusMsg" class="text-sm text-center hidden"></p>
        </form>

        <p class="text-xs text-slate-600 text-center mt-6">Belum punya license key? Hubungi penyedia aplikasi.</p>
      </div>
    </div>
  `;

  document.getElementById('formAktivasi').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = document.getElementById('btnAktivasi');
    const statusMsg = document.getElementById('statusMsg');
    const key = document.getElementById('licenseKeyInput').value.trim().toUpperCase();

    btn.disabled = true;
    btn.textContent = 'Memeriksa...';
    statusMsg.classList.add('hidden');

    const result = await window.api.activateLicense(key);

    if (result.success) {
      statusMsg.textContent = '✓ Aktivasi berhasil!';
      statusMsg.className = 'text-sm text-center text-emerald-400';
      statusMsg.classList.remove('hidden');
      setTimeout(() => onActivated(), 600);
    } else {
      btn.disabled = false;
      btn.textContent = 'Aktifkan';
      statusMsg.textContent = result.error || 'Aktivasi gagal';
      statusMsg.className = 'text-sm text-center text-rose-400';
      statusMsg.classList.remove('hidden');
    }
  });
}
