import { db } from '../utils/db.js';
import { rupiah, todayISO } from '../utils/format.js';

let editId = null;

export async function renderPajak(container) {
  const data = (await db.get('pajak', [])) || [];
  const totalDipungut = data.reduce((a, b) => a + Number(b.jumlah), 0);
  const totalDisetor = data.filter((p) => p.statusSetor === 'sudah').reduce((a, b) => a + Number(b.jumlah), 0);
  const belumSetor = totalDipungut - totalDisetor;

  container.innerHTML = `
    <div class="p-6 space-y-6">
      <div class="flex justify-between items-center no-print">
        <div>
          <h1 class="text-2xl font-bold">Pajak</h1>
          <p class="text-slate-400 text-sm mt-1">Pencatatan pajak yang dipungut dan status penyetoran</p>
        </div>
        <button id="btnTambah" class="px-4 py-2 bg-brand-600 hover:bg-brand-700 rounded-lg text-sm font-medium">+ Tambah Pajak</button>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="bg-slate-900 rounded-xl border border-slate-800 p-5">
          <p class="text-slate-400 text-xs mb-1">Total Dipungut</p>
          <p class="text-xl font-bold">${rupiah(totalDipungut)}</p>
        </div>
        <div class="bg-slate-900 rounded-xl border border-slate-800 p-5">
          <p class="text-slate-400 text-xs mb-1">Sudah Disetor</p>
          <p class="text-xl font-bold text-emerald-400">${rupiah(totalDisetor)}</p>
        </div>
        <div class="bg-slate-900 rounded-xl border border-slate-800 p-5">
          <p class="text-slate-400 text-xs mb-1">Belum Disetor</p>
          <p class="text-xl font-bold text-rose-400">${rupiah(belumSetor)}</p>
        </div>
      </div>

      <div id="formArea" class="hidden bg-slate-900 border border-slate-800 rounded-xl p-5 no-print"></div>

      <div class="bg-slate-900 rounded-xl border border-slate-800 overflow-hidden">
        <table class="w-full text-sm">
          <thead class="bg-slate-800/50 text-slate-400 text-xs uppercase">
            <tr>
              <th class="text-left px-4 py-3">Tanggal</th>
              <th class="text-left px-4 py-3">Jenis Pajak</th>
              <th class="text-left px-4 py-3">Uraian</th>
              <th class="text-right px-4 py-3">Jumlah</th>
              <th class="text-center px-4 py-3">Status</th>
              <th class="text-center px-4 py-3 no-print">Aksi</th>
            </tr>
          </thead>
          <tbody>
            ${
              data.length === 0
                ? `<tr><td colspan="6" class="text-center text-slate-500 py-8">Belum ada data pajak</td></tr>`
                : data
                    .map(
                      (p) => `
              <tr class="border-t border-slate-800 hover:bg-slate-800/30">
                <td class="px-4 py-3">${new Date(p.tanggal).toLocaleDateString('id-ID')}</td>
                <td class="px-4 py-3">${p.jenisPajak}</td>
                <td class="px-4 py-3 text-slate-400">${p.uraian || '-'}</td>
                <td class="px-4 py-3 text-right">${rupiah(p.jumlah)}</td>
                <td class="px-4 py-3 text-center">
                  <span class="px-2 py-1 rounded-full text-xs ${p.statusSetor === 'sudah' ? 'bg-emerald-900 text-emerald-300' : 'bg-amber-900 text-amber-300'}">
                    ${p.statusSetor === 'sudah' ? 'Sudah Disetor' : 'Belum Disetor'}
                  </span>
                </td>
                <td class="px-4 py-3 text-center no-print">
                  <button data-edit="${p.id}" class="text-brand-400 hover:underline text-xs mr-2">Edit</button>
                  <button data-hapus="${p.id}" class="text-rose-400 hover:underline text-xs">Hapus</button>
                </td>
              </tr>`
                    )
                    .join('')
            }
          </tbody>
        </table>
      </div>
    </div>
  `;

  document.getElementById('btnTambah').addEventListener('click', () => openForm(container));
  container.querySelectorAll('[data-edit]').forEach((btn) =>
    btn.addEventListener('click', () => openForm(container, btn.dataset.edit, data))
  );
  container.querySelectorAll('[data-hapus]').forEach((btn) =>
    btn.addEventListener('click', async () => {
      if (!confirm('Hapus data pajak ini?')) return;
      const updated = data.filter((p) => p.id !== btn.dataset.hapus);
      await db.set('pajak', updated);
      renderPajak(container);
    })
  );
}

function openForm(container, id = null, data = []) {
  editId = id;
  const existing = id ? data.find((p) => p.id === id) : null;
  const area = document.getElementById('formArea');
  area.classList.remove('hidden');
  area.innerHTML = `
    <h3 class="font-semibold mb-4">${existing ? 'Edit' : 'Tambah'} Data Pajak</h3>
    <form id="formPajak" class="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div>
        <label class="text-xs text-slate-400 block mb-1">Tanggal</label>
        <input type="date" name="tanggal" value="${existing?.tanggal || todayISO()}" required
          class="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm" />
      </div>
      <div>
        <label class="text-xs text-slate-400 block mb-1">Jenis Pajak</label>
        <select name="jenisPajak" class="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm">
          ${['PPN', 'PPh 21', 'PPh 22', 'PPh 23', 'Lainnya']
            .map((j) => `<option ${existing?.jenisPajak === j ? 'selected' : ''}>${j}</option>`)
            .join('')}
        </select>
      </div>
      <div>
        <label class="text-xs text-slate-400 block mb-1">Status Setor</label>
        <select name="statusSetor" class="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm">
          <option value="belum" ${existing?.statusSetor === 'belum' ? 'selected' : ''}>Belum Disetor</option>
          <option value="sudah" ${existing?.statusSetor === 'sudah' ? 'selected' : ''}>Sudah Disetor</option>
        </select>
      </div>
      <div class="md:col-span-2">
        <label class="text-xs text-slate-400 block mb-1">Uraian</label>
        <input type="text" name="uraian" value="${existing?.uraian || ''}" placeholder="Misal: Pajak pembelian ATK"
          class="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm" />
      </div>
      <div>
        <label class="text-xs text-slate-400 block mb-1">Jumlah (Rp)</label>
        <input type="number" name="jumlah" value="${existing?.jumlah || ''}" required min="0"
          class="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm" />
      </div>
      <div class="md:col-span-3 flex gap-2 justify-end pt-2">
        <button type="button" id="btnBatal" class="px-4 py-2 bg-slate-800 rounded-lg text-sm">Batal</button>
        <button type="submit" class="px-4 py-2 bg-brand-600 hover:bg-brand-700 rounded-lg text-sm font-medium">Simpan</button>
      </div>
    </form>
  `;

  document.getElementById('btnBatal').addEventListener('click', () => area.classList.add('hidden'));
  document.getElementById('formPajak').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const payload = Object.fromEntries(fd.entries());
    let list = (await db.get('pajak', [])) || [];

    if (editId) {
      list = list.map((p) => (p.id === editId ? { ...p, ...payload } : p));
    } else {
      list.push({ id: db.uid(), ...payload });
    }
    await db.set('pajak', list);
    editId = null;
    renderPajak(container);
  });
}
