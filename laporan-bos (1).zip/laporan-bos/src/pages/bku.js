import { db } from '../utils/db.js';
import { rupiah, todayISO } from '../utils/format.js';

let editId = null;

export async function renderBKU(container) {
  const data = (await db.get('bku', [])) || [];
  const sorted = [...data].sort((a, b) => new Date(a.tanggal) - new Date(b.tanggal));
  let saldoBerjalan = 0;

  container.innerHTML = `
    <div class="p-6 space-y-6">
      <div class="flex justify-between items-center no-print">
        <div>
          <h1 class="text-2xl font-bold">Buku Kas Umum (BKU)</h1>
          <p class="text-slate-400 text-sm mt-1">Catat semua pemasukan dan pengeluaran dana BOS</p>
        </div>
        <div class="flex gap-2">
          <button id="btnPrint" class="px-4 py-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-sm font-medium">🖨️ Cetak</button>
          <button id="btnTambah" class="px-4 py-2 bg-brand-600 hover:bg-brand-700 rounded-lg text-sm font-medium">+ Tambah Transaksi</button>
        </div>
      </div>

      <div id="formArea" class="hidden bg-slate-900 border border-slate-800 rounded-xl p-5 no-print"></div>

      <div class="bg-slate-900 rounded-xl border border-slate-800 overflow-hidden print-area">
        <table class="w-full text-sm">
          <thead class="bg-slate-800/50 text-slate-400 text-xs uppercase">
            <tr>
              <th class="text-left px-4 py-3">Tanggal</th>
              <th class="text-left px-4 py-3">Uraian</th>
              <th class="text-left px-4 py-3">Kode Rekening</th>
              <th class="text-right px-4 py-3">Penerimaan</th>
              <th class="text-right px-4 py-3">Pengeluaran</th>
              <th class="text-right px-4 py-3">Saldo</th>
              <th class="text-center px-4 py-3 no-print">Aksi</th>
            </tr>
          </thead>
          <tbody id="bkuBody">
            ${
              sorted.length === 0
                ? `<tr><td colspan="7" class="text-center text-slate-500 py-8">Belum ada transaksi</td></tr>`
                : sorted
                    .map((t) => {
                      saldoBerjalan += t.jenis === 'masuk' ? Number(t.jumlah) : -Number(t.jumlah);
                      return `
                <tr class="border-t border-slate-800 hover:bg-slate-800/30">
                  <td class="px-4 py-3">${new Date(t.tanggal).toLocaleDateString('id-ID')}</td>
                  <td class="px-4 py-3">${t.uraian}</td>
                  <td class="px-4 py-3 text-slate-400">${t.kodeRekening || '-'}</td>
                  <td class="px-4 py-3 text-right text-emerald-400">${t.jenis === 'masuk' ? rupiah(t.jumlah) : ''}</td>
                  <td class="px-4 py-3 text-right text-rose-400">${t.jenis === 'keluar' ? rupiah(t.jumlah) : ''}</td>
                  <td class="px-4 py-3 text-right font-medium">${rupiah(saldoBerjalan)}</td>
                  <td class="px-4 py-3 text-center no-print">
                    <button data-edit="${t.id}" class="text-brand-400 hover:underline text-xs mr-2">Edit</button>
                    <button data-hapus="${t.id}" class="text-rose-400 hover:underline text-xs">Hapus</button>
                  </td>
                </tr>`;
                    })
                    .join('')
            }
          </tbody>
        </table>
      </div>
    </div>
  `;

  document.getElementById('btnTambah').addEventListener('click', () => openForm(container));
  document.getElementById('btnPrint').addEventListener('click', () => window.print());

  container.querySelectorAll('[data-edit]').forEach((btn) =>
    btn.addEventListener('click', () => openForm(container, btn.dataset.edit, data))
  );
  container.querySelectorAll('[data-hapus]').forEach((btn) =>
    btn.addEventListener('click', async () => {
      if (!confirm('Hapus transaksi ini?')) return;
      const updated = data.filter((t) => t.id !== btn.dataset.hapus);
      await db.set('bku', updated);
      renderBKU(container);
    })
  );
}

function openForm(container, id = null, data = []) {
  editId = id;
  const existing = id ? data.find((t) => t.id === id) : null;
  const area = document.getElementById('formArea');
  area.classList.remove('hidden');
  area.innerHTML = `
    <h3 class="font-semibold mb-4">${existing ? 'Edit' : 'Tambah'} Transaksi</h3>
    <form id="formBKU" class="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div>
        <label class="text-xs text-slate-400 block mb-1">Tanggal</label>
        <input type="date" name="tanggal" value="${existing?.tanggal || todayISO()}" required
          class="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm" />
      </div>
      <div class="md:col-span-2">
        <label class="text-xs text-slate-400 block mb-1">Uraian</label>
        <input type="text" name="uraian" value="${existing?.uraian || ''}" required placeholder="Misal: Pembelian ATK"
          class="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm" />
      </div>
      <div>
        <label class="text-xs text-slate-400 block mb-1">Kode Rekening</label>
        <input type="text" name="kodeRekening" value="${existing?.kodeRekening || ''}" placeholder="Misal: 5.1.02.01"
          class="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm" />
      </div>
      <div>
        <label class="text-xs text-slate-400 block mb-1">Jenis</label>
        <select name="jenis" class="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm">
          <option value="masuk" ${existing?.jenis === 'masuk' ? 'selected' : ''}>Penerimaan</option>
          <option value="keluar" ${existing?.jenis === 'keluar' ? 'selected' : ''}>Pengeluaran</option>
        </select>
      </div>
      <div>
        <label class="text-xs text-slate-400 block mb-1">Jumlah (Rp)</label>
        <input type="number" name="jumlah" value="${existing?.jumlah || ''}" required min="0"
          class="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm" />
      </div>
      <div class="md:col-span-3 flex gap-2 justify-end pt-2">
        <button type="button" id="btnBatal" class="px-4 py-2 bg-slate-800 rounded-lg text-sm">Batal</button>
        <button type="submit" class="px-4 py-2 bg-brand-600 hover:bg-brand-700 rounded-lg text-sm font-medium">Simpan</button>
      </div>
    </form>
  `;

  document.getElementById('btnBatal').addEventListener('click', () => area.classList.add('hidden'));
  document.getElementById('formBKU').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const payload = Object.fromEntries(fd.entries());
    let list = (await db.get('bku', [])) || [];

    if (editId) {
      list = list.map((t) => (t.id === editId ? { ...t, ...payload } : t));
    } else {
      list.push({ id: db.uid(), ...payload });
    }
    await db.set('bku', list);
    editId = null;
    renderBKU(container);
  });
}
