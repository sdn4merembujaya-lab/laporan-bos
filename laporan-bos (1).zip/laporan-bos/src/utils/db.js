// Lapisan penyimpanan data. Jika berjalan di dalam Electron, memakai window.api
// (IPC ke electron-store, tersimpan di disk). Jika dibuka langsung di browser
// (mode development web), otomatis fallback ke localStorage agar tetap bisa dites.

const hasElectron = typeof window !== 'undefined' && !!window.api;

async function get(key, fallback = null) {
  if (hasElectron) {
    const val = await window.api.getData(key);
    return val === undefined ? fallback : val;
  }
  const raw = localStorage.getItem(key);
  return raw ? JSON.parse(raw) : fallback;
}

async function set(key, value) {
  if (hasElectron) return window.api.setData(key, value);
  localStorage.setItem(key, JSON.stringify(value));
}

async function del(key) {
  if (hasElectron) return window.api.deleteData(key);
  localStorage.removeItem(key);
}

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

export const db = { get, set, delete: del, uid };
