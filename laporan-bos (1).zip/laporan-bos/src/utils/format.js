export function rupiah(angka) {
  const n = Number(angka) || 0;
  return 'Rp ' + n.toLocaleString('id-ID', { minimumFractionDigits: 0 });
}

export function tanggalIndo(iso) {
  if (!iso) return '-';
  const d = new Date(iso);
  return d.toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' });
}

export function bulanTahun(iso) {
  if (!iso) return '-';
  const d = new Date(iso);
  return d.toLocaleDateString('id-ID', { month: 'long', year: 'numeric' });
}

export function todayISO() {
  return new Date().toISOString().slice(0, 10);
}
