import './style.css';
import { checkAndRenderActivation } from './pages/activation.js';
import { renderDashboard } from './pages/dashboard.js';
import { renderBKU } from './pages/bku.js';
import { renderRKAS } from './pages/rkas.js';
import { renderPajak } from './pages/pajak.js';
import { renderLaporan } from './pages/laporan.js';
import { renderProfil } from './pages/profil.js';

const routes = {
  dashboard: { label: 'Dashboard', icon: '📊', render: renderDashboard },
  bku: { label: 'Buku Kas Umum', icon: '📒', render: renderBKU },
  rkas: { label: 'RKAS', icon: '📋', render: renderRKAS },
  pajak: { label: 'Pajak', icon: '🧾', render: renderPajak },
  laporan: { label: 'Laporan', icon: '🖨️', render: renderLaporan },
  profil: { label: 'Profil Sekolah', icon: '🏫', render: renderProfil },
};

function buildLayout() {
  const app = document.getElementById('app');
  app.innerHTML = `
    <div class="flex h-screen overflow-hidden">
      <aside class="w-64 bg-slate-900 border-r border-slate-800 flex flex-col no-print">
        <div class="px-5 py-5 border-b border-slate-800">
          <h1 class="font-bold text-lg">💰 Laporan BOS</h1>
          <p class="text-xs text-slate-500">Aplikasi Keuangan Sekolah</p>
        </div>
        <nav id="nav" class="flex-1 overflow-y-auto scrollbar-thin p-3 space-y-1"></nav>
        <div class="px-5 py-3 border-t border-slate-800 text-xs text-slate-600">v1.0.0</div>
      </aside>
      <main id="content" class="flex-1 overflow-y-auto scrollbar-thin"></main>
    </div>
  `;

  const nav = document.getElementById('nav');
  nav.innerHTML = Object.entries(routes)
    .map(
      ([key, r]) => `
    <button data-route="${key}" class="nav-btn w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium flex items-center gap-2 text-slate-400 hover:bg-slate-800 hover:text-white transition">
      <span>${r.icon}</span><span>${r.label}</span>
    </button>`
    )
    .join('');

  nav.querySelectorAll('.nav-btn').forEach((btn) => {
    btn.addEventListener('click', () => navigate(btn.dataset.route));
  });
}

function setActive(route) {
  document.querySelectorAll('.nav-btn').forEach((btn) => {
    const isActive = btn.dataset.route === route;
    btn.classList.toggle('bg-brand-600', isActive);
    btn.classList.toggle('text-white', isActive);
    btn.classList.toggle('text-slate-400', !isActive);
  });
}

function navigate(route) {
  const target = routes[route] ? route : 'dashboard';
  const content = document.getElementById('content');
  setActive(target);
  routes[target].render(content);
  window.location.hash = target;
}

checkAndRenderActivation(() => {
  buildLayout();
  navigate(window.location.hash.replace('#', '') || 'dashboard');

  window.addEventListener('hashchange', () => {
    navigate(window.location.hash.replace('#', ''));
  });
});
