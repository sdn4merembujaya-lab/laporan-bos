# 💰 Laporan BOS

Aplikasi desktop untuk manajemen keuangan dana BOS sekolah — dibangun dengan **Electron + Vite + Tailwind CSS**.

## Fitur

- **Dashboard** — ringkasan saldo, pemasukan/pengeluaran, progres RKAS
- **Buku Kas Umum (BKU)** — catat transaksi kas, saldo berjalan otomatis
- **RKAS** — rencana & realisasi anggaran per kegiatan
- **Pajak** — pencatatan pajak dipungut & status setor
- **Laporan** — cetak BKU bulanan dengan kop surat resmi & tanda tangan
- **Profil Sekolah** — data kop surat (nama sekolah, NPSN, kepala sekolah, bendahara)
- Data tersimpan lokal di perangkat (electron-store), tidak perlu internet

## Menjalankan (Development)

```bash
npm install
npm run electron:dev
```

Ini akan menjalankan Vite dev server + Electron secara bersamaan.

## Build Aplikasi Desktop

```bash
npm run dist:win     # Windows (.exe installer)
npm run dist:mac     # macOS (.dmg)
npm run dist:linux   # Linux (.AppImage)
```

Hasil build ada di folder `release/`.

## Struktur Folder

```
├── electron/          # Proses utama Electron (main.js, preload.js)
├── src/
│   ├── pages/          # Setiap halaman (dashboard, bku, rkas, pajak, laporan, profil)
│   ├── utils/           # Helper (db.js untuk penyimpanan, format.js untuk format Rupiah/tanggal)
│   ├── main.js          # Entry point + layout sidebar + router
│   └── style.css
├── public/               # Icon aplikasi
├── index.html
├── vite.config.js
├── tailwind.config.js
└── package.json
```

## Teknologi

- Electron 31
- Vite 5
- Tailwind CSS 3
- electron-store (penyimpanan data lokal)
- electron-builder (build installer)

## Lisensi

MIT

## Sistem Lisensi (Aktivasi Online)

Aplikasi ini punya sistem lisensi terpisah di folder `license-server/`. Model kerjanya:

1. Kamu **deploy `license-server/`** ke layanan hosting (Railway, Render, VPS, dll) — gratis untuk skala kecil.
2. Kamu **generate license key** untuk tiap pelanggan/sekolah lewat `generate-key.js` atau endpoint admin.
3. Pengguna **memasukkan key** saat pertama kali membuka aplikasi → aplikasi menghubungi server kamu untuk aktivasi.
4. Setelah aktif, aplikasi **bisa dipakai offline** (ada masa tenggang 14 hari tanpa perlu online, bisa diubah di `electron/license-config.js`).
5. Kamu bisa **batasi jumlah perangkat per key**, set **masa berlaku**, dan **cabut (revoke)** akses kapan saja dari server.

### Setup license server

```bash
cd license-server
npm install
cp .env.example .env
# edit .env, ganti ADMIN_SECRET dengan secret rahasia kamu sendiri
npm start
```

### Generate license key baru

```bash
node generate-key.js "SDN 4 Merembu Jaya" 2 365
# argumen: nama pelanggan | maks perangkat | masa berlaku (hari, kosongkan = seumur hidup)
```

### Deploy ke online (contoh: Railway/Render)

1. Push folder `license-server/` sebagai repo terpisah (atau subfolder) ke GitHub.
2. Deploy ke Railway/Render, set environment variable `ADMIN_SECRET`.
3. Setelah dapat URL publik (misal `https://laporan-bos-license.up.railway.app`), buka `electron/license-config.js` di project utama dan ganti `LICENSE_SERVER_URL` ke URL tersebut.
4. Rebuild aplikasi Electron (`npm run dist:win`) dan distribusikan ke pelanggan.

Dengan begini, **siapa saja di mana saja bisa mengaktifkan aplikasi** selama mereka punya license key yang valid dan koneksi internet saat aktivasi pertama kali — tapi kamu tetap yang mengontrol siapa boleh pakai.
