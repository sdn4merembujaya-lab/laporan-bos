import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.join(__dirname, 'licenses.json');

function load() {
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify({ licenses: [] }, null, 2));
  }
  return JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'));
}

function save(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

export function getAllLicenses() {
  return load().licenses;
}

export function findLicense(key) {
  return load().licenses.find((l) => l.key === key);
}

export function addLicense(license) {
  const data = load();
  data.licenses.push(license);
  save(data);
  return license;
}

export function updateLicense(key, updater) {
  const data = load();
  const idx = data.licenses.findIndex((l) => l.key === key);
  if (idx === -1) return null;
  data.licenses[idx] = updater(data.licenses[idx]);
  save(data);
  return data.licenses[idx];
}
