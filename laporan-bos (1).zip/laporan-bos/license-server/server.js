import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { getAllLicenses, findLicense, addLicense, updateLicense } from './db.js';
import { generateLicenseKey } from './keygen.js';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 4000;
const ADMIN_SECRET = process.env.ADMIN_SECRET || 'ganti-secret-ini';

function requireAdmin(req, res, next) {
  const secret = req.headers['x-admin-secret'];
  if (secret !== ADMIN_SECRET) {
    return res.status(401).json({ ok: false, error: 'Admin secret salah' });
  }
  next();
}

function isExpired(license) {
  if (!license.expiresAt) return false;
  return new Date(license.expiresAt) < new Date();
}

// ---- Publik: dipanggil oleh aplikasi Electron ----

app.post('/api/activate', (req, res) => {
  const { key, deviceId, deviceName } = req.body || {};
  if (!key || !deviceId) {
    return res.status(400).json({ ok: false, error: 'key dan deviceId wajib diisi' });
  }

  const license = findLicense(key);
  if (!license) return res.status(404).json({ ok: false, error: 'License key tidak ditemukan' });
  if (license.status === 'revoked') return res.status(403).json({ ok: false, error: 'License key sudah dicabut' });
  if (isExpired(license)) return res.status(403).json({ ok: false, error: 'License key sudah kedaluwarsa' });

  const alreadyActivated = license.devices.find((d) => d.deviceId === deviceId);
  if (alreadyActivated) {
    updateLicense(key, (l) => {
      alreadyActivated.lastSeen = new Date().toISOString();
      return l;
    });
    return res.json({ ok: true, message: 'Perangkat sudah aktif sebelumnya', expiresAt: license.expiresAt });
  }

  if (license.devices.length >= license.maxDevices) {
    return res.status(403).json({
      ok: false,
      error: `Batas maksimal ${license.maxDevices} perangkat untuk key ini sudah tercapai`,
    });
  }

  const updated = updateLicense(key, (l) => {
    l.devices.push({
      deviceId,
      deviceName: deviceName || 'Tidak diketahui',
      activatedAt: new Date().toISOString(),
      lastSeen: new Date().toISOString(),
    });
    return l;
  });

  res.json({ ok: true, message: 'Aktivasi berhasil', expiresAt: updated.expiresAt });
});

app.post('/api/validate', (req, res) => {
  const { key, deviceId } = req.body || {};
  if (!key || !deviceId) {
    return res.status(400).json({ ok: false, error: 'key dan deviceId wajib diisi' });
  }

  const license = findLicense(key);
  if (!license) return res.status(404).json({ ok: false, valid: false, error: 'License tidak ditemukan' });
  if (license.status === 'revoked') return res.json({ ok: true, valid: false, error: 'License dicabut' });
  if (isExpired(license)) return res.json({ ok: true, valid: false, error: 'License kedaluwarsa' });

  const device = license.devices.find((d) => d.deviceId === deviceId);
  if (!device) return res.json({ ok: true, valid: false, error: 'Perangkat ini belum diaktivasi untuk key ini' });

  updateLicense(key, (l) => {
    device.lastSeen = new Date().toISOString();
    return l;
  });

  res.json({ ok: true, valid: true, expiresAt: license.expiresAt, customerName: license.customerName });
});

// ---- Admin: kelola license key (dilindungi ADMIN_SECRET) ----

app.post('/api/admin/generate', requireAdmin, (req, res) => {
  const { customerName, maxDevices = 1, expiresInDays = null } = req.body || {};
  const key = generateLicenseKey();
  const license = {
    key,
    customerName: customerName || 'Tanpa nama',
    maxDevices: Number(maxDevices),
    expiresAt: expiresInDays ? new Date(Date.now() + expiresInDays * 86400000).toISOString() : null,
    status: 'active',
    devices: [],
    createdAt: new Date().toISOString(),
  };
  addLicense(license);
  res.json({ ok: true, license });
});

app.get('/api/admin/licenses', requireAdmin, (req, res) => {
  res.json({ ok: true, licenses: getAllLicenses() });
});

app.post('/api/admin/revoke', requireAdmin, (req, res) => {
  const { key } = req.body || {};
  const updated = updateLicense(key, (l) => {
    l.status = 'revoked';
    return l;
  });
  if (!updated) return res.status(404).json({ ok: false, error: 'Key tidak ditemukan' });
  res.json({ ok: true, license: updated });
});

app.post('/api/admin/activate-key', requireAdmin, (req, res) => {
  const { key } = req.body || {};
  const updated = updateLicense(key, (l) => {
    l.status = 'active';
    return l;
  });
  if (!updated) return res.status(404).json({ ok: false, error: 'Key tidak ditemukan' });
  res.json({ ok: true, license: updated });
});

app.get('/', (req, res) => res.json({ ok: true, service: 'Laporan BOS License Server' }));

app.listen(PORT, () => console.log(`License server jalan di port ${PORT}`));
