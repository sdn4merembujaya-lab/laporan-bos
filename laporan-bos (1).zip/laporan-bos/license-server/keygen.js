import crypto from 'crypto';

const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // tanpa 0,O,1,I biar tidak rancu

function randomGroup(len = 4) {
  let out = '';
  const bytes = crypto.randomBytes(len);
  for (let i = 0; i < len; i++) {
    out += ALPHABET[bytes[i] % ALPHABET.length];
  }
  return out;
}

export function generateLicenseKey() {
  return `LBOS-${randomGroup()}-${randomGroup()}-${randomGroup()}-${randomGroup()}`;
}
