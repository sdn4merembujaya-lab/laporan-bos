// Pakai: node generate-key.js "Nama Sekolah" 3 365
// argumen: nama pelanggan, maks perangkat, masa berlaku (hari, kosongkan utk seumur hidup)
import 'dotenv/config';

const SERVER_URL = process.env.SERVER_URL || `http://localhost:${process.env.PORT || 4000}`;
const ADMIN_SECRET = process.env.ADMIN_SECRET || 'ganti-secret-ini';

const [customerName, maxDevices = '1', expiresInDays] = process.argv.slice(2);

if (!customerName) {
  console.log('Pakai: node generate-key.js "Nama Sekolah/Pelanggan" [maxDevices] [expiresInDays]');
  process.exit(1);
}

const res = await fetch(`${SERVER_URL}/api/admin/generate`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json', 'x-admin-secret': ADMIN_SECRET },
  body: JSON.stringify({
    customerName,
    maxDevices: Number(maxDevices),
    expiresInDays: expiresInDays ? Number(expiresInDays) : null,
  }),
});

const data = await res.json();
if (!data.ok) {
  console.error('Gagal:', data.error);
  process.exit(1);
}

console.log('✅ License key berhasil dibuat:\n');
console.log('   Key           :', data.license.key);
console.log('   Pelanggan     :', data.license.customerName);
console.log('   Maks Perangkat:', data.license.maxDevices);
console.log('   Kedaluwarsa   :', data.license.expiresAt || 'Seumur hidup');
