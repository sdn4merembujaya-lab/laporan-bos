const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  getData: (key) => ipcRenderer.invoke('data:get', key),
  setData: (key, value) => ipcRenderer.invoke('data:set', key, value),
  deleteData: (key) => ipcRenderer.invoke('data:delete', key),
  getAllData: () => ipcRenderer.invoke('data:getAll'),
  getVersion: () => ipcRenderer.invoke('app:getVersion'),
  print: () => window.print(),

  checkLicenseStatus: () => ipcRenderer.invoke('license:checkStatus'),
  activateLicense: (key) => ipcRenderer.invoke('license:activate', key),
  deactivateLicense: () => ipcRenderer.invoke('license:deactivate'),
  getDeviceId: () => ipcRenderer.invoke('license:getDeviceId'),
});
