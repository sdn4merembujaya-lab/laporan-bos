const crypto = require('crypto');
const os = require('os');
const { LICENSE_SERVER_URL, OFFLINE_GRACE_DAYS } = require('./license-config');

function getDeviceId() {
  const raw = [os.hostname(), os.platform(), os.arch(), os.cpus()?.[0]?.model || ''].join('|');
  return crypto.createHash('sha256').update(raw).digest('hex').slice(0, 32);
}

function getDeviceName() {
  return `${os.hostname()} (${os.platform()})`;
}

async function activate(store, key) {
  const deviceId = getDeviceId();
  try {
    const res = await fetch(`${LICENSE_SERVER_URL}/api/activate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key, deviceId, deviceName: getDeviceName() }),
    });
    const data = await res.json();

    if (!data.ok) {
      return { success: false, error: data.error || 'Aktivasi gagal' };
    }

    store.set('license', {
      key,
      deviceId,
      expiresAt: data.expiresAt || null,
      lastValidatedAt: new Date().toISOString(),
      valid: true,
    });

    return { success: true };
  } catch (err) {
    return { success: false, error: 'Tidak bisa terhubung ke server lisensi. Periksa koneksi internet.' };
  }
}

async function checkStatus(store) {
  const license = store.get('license');
  if (!license || !license.key) {
    return { activated: false };
  }

  // Jika sudah lewat masa berlaku yang tercatat lokal, langsung tolak
  if (license.expiresAt && new Date(license.expiresAt) < new Date()) {
    return { activated: false, error: 'License sudah kedaluwarsa' };
  }

  const deviceId = getDeviceId();

  try {
    const res = await fetch(`${LICENSE_SERVER_URL}/api/validate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key: license.key, deviceId }),
    });
    const data = await res.json();

    if (data.ok && data.valid) {
      store.set('license', {
        ...license,
        expiresAt: data.expiresAt || null,
        lastValidatedAt: new Date().toISOString(),
        valid: true,
      });
      return { activated: true };
    }

    // Server menjawab tapi bilang tidak valid (revoked/expired/device lain)
    return { activated: false, error: data.error || 'License tidak valid' };
  } catch (err) {
    // Tidak ada internet — pakai masa tenggang offline berdasar validasi online terakhir
    const lastValidated = new Date(license.lastValidatedAt || 0);
    const daysSince = (Date.now() - lastValidated.getTime()) / 86400000;

    if (license.valid && daysSince <= OFFLINE_GRACE_DAYS) {
      return { activated: true, offline: true };
    }
    return { activated: false, error: 'Tidak bisa memverifikasi lisensi (offline terlalu lama). Sambungkan internet.' };
  }
}

function deactivate(store) {
  store.delete('license');
}

module.exports = { activate, checkStatus, deactivate, getDeviceId };
