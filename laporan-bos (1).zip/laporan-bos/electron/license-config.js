// Ganti URL ini dengan alamat license-server yang sudah kamu deploy online
// (misal setelah deploy ke Railway/Render: https://laporan-bos-license.up.railway.app)
module.exports = {
  LICENSE_SERVER_URL: process.env.LICENSE_SERVER_URL || 'http://localhost:4000',
  // Berapa hari boleh dipakai offline sebelum wajib online-check lagi
  OFFLINE_GRACE_DAYS: 14,
};
