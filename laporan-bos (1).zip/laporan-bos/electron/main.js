const { app, BrowserWindow, Menu, ipcMain, dialog } = require('electron');
const path = require('path');
const Store = require('electron-store');
const license = require('./license');

const isDev = process.env.NODE_ENV === 'development';
const store = new Store({ name: 'laporan-bos-data' });

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 1024,
    minHeight: 640,
    icon: path.join(__dirname, '../public/icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
    backgroundColor: '#0f172a',
    show: false,
  });

  mainWindow.once('ready-to-show', () => mainWindow.show());

  if (isDev) {
    mainWindow.loadURL('http://localhost:5173');
    mainWindow.webContents.openDevTools();
  } else {
    mainWindow.loadFile(path.join(__dirname, '../dist/index.html'));
  }

  buildMenu();
}

function buildMenu() {
  const template = [
    {
      label: 'Berkas',
      submenu: [
        {
          label: 'Cetak Laporan',
          accelerator: 'CmdOrCtrl+P',
          click: () => mainWindow.webContents.print({ printBackground: true }),
        },
        {
          label: 'Export PDF',
          click: async () => {
            const pdf = await mainWindow.webContents.printToPDF({ printBackground: true });
            const { filePath } = await dialog.showSaveDialog(mainWindow, {
              defaultPath: `Laporan-BOS-${Date.now()}.pdf`,
              filters: [{ name: 'PDF', extensions: ['pdf'] }],
            });
            if (filePath) require('fs').writeFileSync(filePath, pdf);
          },
        },
        { type: 'separator' },
        { role: 'quit', label: 'Keluar' },
      ],
    },
    {
      label: 'Tampilan',
      submenu: [
        { role: 'reload', label: 'Muat Ulang' },
        { role: 'toggleDevTools', label: 'Developer Tools' },
        { type: 'separator' },
        { role: 'resetZoom', label: 'Reset Zoom' },
        { role: 'zoomIn', label: 'Perbesar' },
        { role: 'zoomOut', label: 'Perkecil' },
        { type: 'separator' },
        { role: 'togglefullscreen', label: 'Layar Penuh' },
      ],
    },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

// ---- IPC: penyimpanan data lokal (BKU, RKAS, Pajak) ----
ipcMain.handle('data:get', (_e, key) => store.get(key));
ipcMain.handle('data:set', (_e, key, value) => store.set(key, value));
ipcMain.handle('data:delete', (_e, key) => store.delete(key));
ipcMain.handle('data:getAll', () => store.store);

ipcMain.handle('app:getVersion', () => app.getVersion());

// ---- IPC: lisensi/aktivasi ----
ipcMain.handle('license:checkStatus', () => license.checkStatus(store));
ipcMain.handle('license:activate', (_e, key) => license.activate(store, key));
ipcMain.handle('license:deactivate', () => license.deactivate(store));
ipcMain.handle('license:getDeviceId', () => license.getDeviceId());

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
